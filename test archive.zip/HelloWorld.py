# https://www.guru99.com/how-to-install-python.html

def main():
   print("Hello World!!!")
   f=0 # Declare a variable and initialize it
   print(f)

   f='Im used again' # re-declaring the variable works

   print(f)

   print("Concatenate"+str(99)) #cant not concatenate different data types

if __name__=="__main__":
    main()
print("Guru")